﻿using System;
using Arrow.DeveloperTest.Types;
using Arrow.DeveloperTest.Services;
using System.Configuration;

namespace Arrow.DeveloperTest.Runner
{
    public class Program
    {
        MakePaymentRequest request = new MakePaymentRequest();

        static void Main(string[] args)
        {

            Console.WriteLine(" inside main ");

            PaymentService paymentServiceObj = new PaymentService();

            DateTime dateTime = DateTime.UtcNow.Date;

            MakePaymentRequest request = new MakePaymentRequest();
            request.CreditorAccountNumber = "12345678";
            request.DebtorAccountNumber = "910112356";
            request.Amount = 20;
            request.PaymentDate = dateTime;
            request.PaymentScheme = Arrow.DeveloperTest.Types.PaymentScheme.Bacs;

            paymentServiceObj.MakePayment(request);

        }
    }
}
