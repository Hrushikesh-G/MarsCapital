﻿using System;
using Arrow.DeveloperTest.Services;
using Arrow.DeveloperTest.Types;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Arrow.DeveloperTest.Tests
{

    [TestClass]
    public class TestClass
    {
        [TestMethod]

        //  Test case 1 :
        /*
         payment scheme is Bacs
         Existing Account is not null
         and allowed payment scheme is AllowedPaymentSchemes

         >> Test Case : Success 
         >> Result will be True 
         */




        public void TestMethodBacs()
        {
            PaymentService paymentServiceObj = new PaymentService();

            DateTime dateTime = DateTime.UtcNow.Date;

            MakePaymentRequest request = new MakePaymentRequest();
            request.CreditorAccountNumber = "12345678";
            request.DebtorAccountNumber = "910112356";
            request.Amount = 20;
            request.PaymentDate = dateTime;
            request.PaymentScheme = Arrow.DeveloperTest.Types.PaymentScheme.Bacs;

            paymentServiceObj.MakePayment(request);
        }


        /*
        Existing Account is null 
        and If payment scheme is not equals to FasterPayments >> true
        and current account balance is less than Requested Amount
        >>> Result will be false

        Test case Result : Success
        expected Output: Success : false
        */

        [TestMethod]
        public void TestMethodFasterPayments()
        {
            PaymentService paymentServiceObj = new PaymentService();

            DateTime dateTime = DateTime.UtcNow.Date;

            MakePaymentRequest request = new MakePaymentRequest();
            request.CreditorAccountNumber = "12345675";
            request.DebtorAccountNumber = "910112356";
            request.Amount = 600;
            request.PaymentDate = dateTime;
            request.PaymentScheme = Arrow.DeveloperTest.Types.PaymentScheme.FasterPayments;

            paymentServiceObj.MakePayment(request);
        }

        /*
         * Existing Account object is not null
         * Payment type is equals to Chaps
         * and account status is equals to live
         * 
         * Test Case : Success
         * Expected Result : True
         *
         
         */

        [TestMethod]
        public void TestMethodChaps()
        {
            PaymentService paymentServiceObj = new PaymentService();

            DateTime dateTime = DateTime.UtcNow.Date;

            MakePaymentRequest request = new MakePaymentRequest();
            request.CreditorAccountNumber = "12344575";
            request.DebtorAccountNumber = "910112356";
            request.PaymentDate = dateTime;
            request.PaymentScheme = Arrow.DeveloperTest.Types.PaymentScheme.Chaps;
            

            paymentServiceObj.MakePayment(request);
        }


        /*
         * Existing Account object is null
         * Payment type is equals to Bacs
         
         * Test Case : Success
         * Expected Result : False
         *

         */

        [TestMethod]
        public void TestMethodNullBacs()
        {
            PaymentService paymentServiceObj = new PaymentService();

            DateTime dateTime = DateTime.UtcNow.Date;

            MakePaymentRequest request = new MakePaymentRequest();
            request.CreditorAccountNumber = "12345678";
            request.DebtorAccountNumber = "910112356";
            request.Amount = 0;
            request.PaymentDate = dateTime;
            request.PaymentScheme = Arrow.DeveloperTest.Types.PaymentScheme.Bacs;

            paymentServiceObj.MakePayment(request);
        }

        /*
         * Existing Account object is null
         * Payment type is equals to Bacs
         * Test Case : Success
         * Expected Result : False
         *

         */

        [TestMethod]
        public void TestMethodNullFasterPayments()
        {
            PaymentService paymentServiceObj = new PaymentService();

            DateTime dateTime = DateTime.UtcNow.Date;

            MakePaymentRequest request = new MakePaymentRequest();
            request.CreditorAccountNumber = "12345675";
            request.DebtorAccountNumber = "910112356";
            request.Amount = 600;
            request.PaymentDate = dateTime;
            request.PaymentScheme = Arrow.DeveloperTest.Types.PaymentScheme.FasterPayments;

            paymentServiceObj.MakePayment(request);
        }

        /*
         * Existing Account object is null
         * Payment type is equals to Chaps
         * and account status is equals to live
         * 
         * Test Case : Success
         * Expected Result : false
         *
         
         */

        [TestMethod]
        public void TestMethodNullChaps()
        {
            PaymentService paymentServiceObj = new PaymentService();

            DateTime dateTime = DateTime.UtcNow.Date;

            MakePaymentRequest request = new MakePaymentRequest();
            request.CreditorAccountNumber = "12344575";
            request.DebtorAccountNumber = "910112356";
            request.PaymentDate = dateTime;
            request.PaymentScheme = Arrow.DeveloperTest.Types.PaymentScheme.Chaps;


            paymentServiceObj.MakePayment(request);
        }
    }
}