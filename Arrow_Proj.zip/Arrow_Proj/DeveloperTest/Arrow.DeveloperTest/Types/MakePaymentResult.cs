﻿namespace Arrow.DeveloperTest.Types
{
    public class MakePaymentResult
    {
        public bool Success { get; set; }
    }
}
