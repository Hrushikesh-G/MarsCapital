﻿namespace Arrow.DeveloperTest.Types
{
    public enum AccountStatus
    {
        Live,
        Disabled,
        InboundPaymentsOnly
    }
}
