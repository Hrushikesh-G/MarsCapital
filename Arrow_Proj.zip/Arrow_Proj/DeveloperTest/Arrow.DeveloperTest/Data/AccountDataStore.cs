﻿using System;

using Arrow.DeveloperTest.Types;

namespace Arrow.DeveloperTest.Data
{
    public class AccountDataStore
    {

        /* fetch account details */
        public Account GetAccount(string accountNumber)
        {

            Account BacsAcc = new Account();

            BacsAcc.AccountNumber = "12345";
            BacsAcc.AllowedPaymentSchemes = AllowedPaymentSchemes.Bacs;
            BacsAcc.Balance = 500;

            Account FasterAcc = new Account();

            FasterAcc.AccountNumber = "12345";
            FasterAcc.AllowedPaymentSchemes = AllowedPaymentSchemes.FasterPayments;
            FasterAcc.Balance = 500;

            Account ChapsAcc = new Account();

            ChapsAcc.AccountNumber = "12345";
            ChapsAcc.AllowedPaymentSchemes = AllowedPaymentSchemes.Chaps;
            ChapsAcc.Status = AccountStatus.Live;
            ChapsAcc.Balance = 500;

            // test case result is depend on the object we return

            return new Account();
        }

        /* Update account info */
        public void UpdateAccount(Account account)
        {
            // Update account in database, code removed for brevity
        }



    }
}
