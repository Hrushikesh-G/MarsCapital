﻿using Arrow.DeveloperTest.Data;
using Arrow.DeveloperTest.Types;
using System;
using System.Configuration;

namespace Arrow.DeveloperTest.Services
{
    // this class is associated with payment services , which serves the single purpose of validating payment request
    // PaymentService class follows the Single Responsibility Principle (SRP)

    public class PaymentService : IPaymentService
    {
        /* Define interface's unimplemented method : MakePaymentResult 
         * MakePaymentResult accepts the parameter of type MakePaymentRequest , which is user's requested transaction:
         */

        public MakePaymentResult MakePayment(MakePaymentRequest request)
        {
            /* AccountDataStore gives update and get method for data*/
            var accountDataStoreGetData = new AccountDataStore();

            /* get account info */
            Account account = accountDataStoreGetData.GetAccount(request.DebtorAccountNumber);
            /*account = already existing account*/

            var result = new MakePaymentResult();

            //Assume 
             result.Success = true;

            /*  FasterPayments,
                Bacs,
                Chaps
            */

            switch (request.PaymentScheme)
            {
                /*Bacs  */
                case PaymentScheme.Bacs:
                    //account does not exists
                    if (account == null)
                    {
                        result.Success = false;
                    }
                      /*
                        FasterPayments = 1 << 0,
                        Bacs = 1 << 1,
                        Chaps = 1 << 2
                      */

                    /* check if payment scheme is Bacs or not */

                    else if (!account.AllowedPaymentSchemes.HasFlag(AllowedPaymentSchemes.Bacs))
                    {
                        result.Success = false;
                    }
                    break;

                case PaymentScheme.FasterPayments:
                    if (account == null)
                    {
                        result.Success = false;
                    }
                    else if (!account.AllowedPaymentSchemes.HasFlag(AllowedPaymentSchemes.FasterPayments))
                    {
                        result.Success = false;
                    }
                    /* Check if fetched account balance is less Request account*/
                    else if (account.Balance < request.Amount)
                    {
                        result.Success = false;
                    }
                    break;

                case PaymentScheme.Chaps: //
                    if (account == null)
                    {
                        result.Success = false;
                    }
                    else if (!account.AllowedPaymentSchemes.HasFlag(AllowedPaymentSchemes.Chaps))
                    {
                        result.Success = false;
                    }
                    else if (account.Status != AccountStatus.Live)
                    {
                        result.Success = false;
                    }
                    break;
            }

            if (result.Success)// if true
            {
                // reduce current account balance
                account.Balance -= request.Amount;

                //Update account balance
                var accountDataStoreUpdateData = new AccountDataStore();
                accountDataStoreUpdateData.UpdateAccount(account);
            }

            Console.WriteLine(" Result: " + result.Success);
            return result;
        }
    }
}
