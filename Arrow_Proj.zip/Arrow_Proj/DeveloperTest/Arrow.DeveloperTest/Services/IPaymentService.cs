﻿using Arrow.DeveloperTest.Types;

namespace Arrow.DeveloperTest.Services
{
    public interface IPaymentService
    {

        //declare the methods
        //data related to payment done by user >> MakePaymentRequest

        // this interface is open for extension it means we can add new methods if required.
        // it follows "O :  Open for extension "
        MakePaymentResult MakePayment(MakePaymentRequest request);
    }
}
